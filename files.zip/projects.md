---
layout: default
title: Projects
nav_order: 3
permalink: /projects/
---

# Projects

Here are some of the projects I've worked on:

- **Project One**: Short description of project one.
- **Project Two**: Short description of project two.

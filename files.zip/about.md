---
layout: default
title: About
nav_order: 2
permalink: /about/
---

# About Me

I'm Pickles33.  
This is a brief introduction about myself, my background, and my interests.
